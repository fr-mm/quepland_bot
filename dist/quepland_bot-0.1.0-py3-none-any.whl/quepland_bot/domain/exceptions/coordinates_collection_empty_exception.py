from quepland_bot.domain.exceptions import DomainException


class CoordinatesCollectionEmptyException(DomainException):
    pass
