from enum import Enum


class KeyboardKeyEnum(Enum):
    SPACE = 'space'
    ESC = 'esc'
