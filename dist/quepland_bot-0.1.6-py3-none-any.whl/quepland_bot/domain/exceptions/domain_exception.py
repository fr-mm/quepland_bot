class DomainException(Exception):
    pass
