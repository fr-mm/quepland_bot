from quepland_bot.application.exceptions.application_exception import ApplicationException


class CoordinatesSequenceNotFoundException(ApplicationException):
    pass
