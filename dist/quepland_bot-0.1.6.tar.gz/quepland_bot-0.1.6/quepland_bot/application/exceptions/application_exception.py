class ApplicationException(Exception):
    pass
